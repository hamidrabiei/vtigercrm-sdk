<?php

/**
 * Get module names for which sharing access can be controlled.
 * NOTE: Ignore the standard modules which is already handled.
 */
function vtlib_getModuleNameForSharing() {
	global $adb;
	$vtlib_sqlres = $adb->query("SELECT * from vtiger_tab WHERE ownedby = 0 
		AND name NOT IN('Calendar','Leads','Accounts','Contacts','Potentials',
			'HelpDesk','Campaigns','Quotes','PurchaseOrder','SalesOrder','Invoice','Events')");
	$vtlib_numrows = $adb->num_rows($vtlib_sqlres);
	$modules = Array();
	for($idx = 0; $idx < $vtlib_numrows; ++$idx) $modules[] = $adb->query_result($vtlib_sqlres, 0, 'name');
	return $modules;
}

/**
 * Check if module is set active (or enabled)
 */
function vtlib_isModuleActive($module) {
	global $adb;
	
	if(in_array($module, vtlib_moduleAlwaysActive())){
		return true;
	}
	
	$tabres = $adb->query("SELECT presence FROM vtiger_tab WHERE name='$module'");

	$active = false;
	if($adb->num_rows($tabres)) {
		$presence = $adb->query_result($tabres, 0, 'presence');
		if($presence != 1) $active = true;
	}
	return $active;
}

/**
 * Get list module names which are always active (cannot be disabled)
 */
function vtlib_moduleAlwaysActive() {
	$modules = Array ('Administration', 'Settings', 'Users', 'Migration', 'Utilities', 'uploads');
	return $modules;
}

/**
 * Toggle the module (enable/disable)
 */
function vtlib_toggleModuleAccess($module, $enable_disable) {
	global $adb;

	if($enable_disable === true) $enable_disable = 0;
	else if($enable_disable === false) $enable_disable = 1;

	$adb->query("UPDATE vtiger_tab set presence = $enable_disable WHERE name = '$module'");

	create_tab_data_file();
	create_parenttab_data_file();
}

/**
 * Get list of module with current status which can be controlled.
 */
function vtlib_getToggleModuleInfo() {
	global $adb;

	$modinfo = Array();

	$sqlresult = $adb->query("SELECT name, presence FROM vtiger_tab WHERE name NOT IN ('Users') AND presence IN (0,1) ORDER BY name");
	$num_rows  = $adb->num_rows($sqlresult);
	for($idx = 0; $idx < $num_rows; ++$idx) {
		$module = $adb->query_result($sqlresult, $idx, 'name');
		$presence=$adb->query_result($sqlresult, $idx, 'presence');

		$modinfo[$module] = $presence;
	}
	return $modinfo;
}

?>
