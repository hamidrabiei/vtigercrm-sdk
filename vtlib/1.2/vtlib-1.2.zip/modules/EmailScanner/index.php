<?php

global $currentModule;
include_once("modules/$currentModule/ListView.php");

?>
