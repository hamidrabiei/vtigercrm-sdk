<?php

$mod_strings = Array(
	'EmailScanner' => 'EmailScanner',

	'LBL_EMAILSCANNER_INFORMATION' => 'Scanner Information',
	'LBL_TIME_INFORMATION' => 'Time Information',
	'LBL_CUSTOM_INFORMATION'=> 'Custom Information',

	'EmailScannerName' => 'EmailScanner Name',
	'Assigned To' => 'Assigned To',
	'Created Time'=> 'Created On',
	'Modified Time'=>'Modified On',
);

?>
