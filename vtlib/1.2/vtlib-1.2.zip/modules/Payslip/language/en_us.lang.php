<?php

$mod_strings = Array(

	'LBL_PAYSLIP_INFORMATION' => 'Payslip Information',
	'LBL_CUSTOM_INFORMATION'  => 'Custom Information',

	'PayslipName' => 'Payslip Name',
	'Month' => 'For Month',
	'Assigned To' => 'Assigned To',
	'Created Time'=> 'Created On',
	'Modified Time'=>'Modified On',
);

?>
