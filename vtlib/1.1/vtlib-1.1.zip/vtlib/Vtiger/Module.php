<?php

include_once('vtlib/Vtiger/Common.inc.php');

class Vtiger_Module {

	static function getId($module_name) {
		global $adb;

		$sqlresult = $adb->query("select tabid from vtiger_tab where name='".Vtiger_Utils::SQLEscape($module_name)."'");
		return $adb->query_result($sqlresult, 0, 'tabid');
	}
}

?>

