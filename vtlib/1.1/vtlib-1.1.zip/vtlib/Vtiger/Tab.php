<?php

include_once('vtlib/Vtiger/Common.inc.php');
include_once('vtlib/Vtiger/Module.php');

include_once('vtlib/Vtiger/ParentTab.php');

class Vtiger_Tab extends Vtiger_Module {

	/**
	 * Create A New Tab (Menu Sub Item)
	 */
	static function create($tabname, $tablabel, $parent_tabname) {
		global $adb;

		$tabid = self::getUniqueId();
		$presence = 0;
		$tabsequence = self::getNextSequence();

		$tabsql = "INSERT INTO vtiger_tab (tabid,name,presence,tabsequence,tablabel,modifiedby,modifiedtime,customized,ownedby)
               VALUES ($tabid, '$tabname', '$presence', '$tabsequence', '$tablabel', NULL, NULL, 0, 1)";

		$adb->query($tabsql);

		Vtiger_ParentTab::add($tabid, $parent_tabname);

		self::addToProfile($tabid);

		self::syncToFile();

		Vtiger_Utils::Log("Creating new menu item $tabname ($tablabel) ... DONE");
		Vtiger_Utils::Log("Check Language Mapping entry for $tablabel ... TODO");

		return $tabid;
	}

	/**
	 * Enable tab access control for each profile.
	 */
	static function addToProfile($tabid) {
		global $adb;

		$sqlresult = $adb->query("select profileid from vtiger_profile");
		$profilecnt = $adb->num_rows($sqlresult);
		for($pridx = 0; $pridx < $profilecnt; ++$pridx) {
			$profileid = $adb->query_result($sqlresult, $pridx, "profileid");
			$adb->query("INSERT INTO vtiger_profile2tab (profileid, tabid, permissions) VALUES($profileid, $tabid,0)");
		}
	}

	/**
	 * Enable module action like, Import/Export/Merge etc..
	 */
	static function enableAction($module, $action, $profileid=null) {
		self::updateAction($module, $action, true, $profileid);
	}
	/**
	 * Disable module action like, Import/Export/Merge etc...
	 */
	static function disableAction($module, $action, $profileid=null) {
		self::updateAction($module, $action, false, $profileid);
	}

	/**
	 * Common function to enable or disable action (tools) for module
	 * Actions are defined in the table vtiger_actionmapping like Import, Export etc...
	 */
	static function updateAction($module, $action, $enable_disable, $profile_id=null) {
		global $adb;

		$tabid = self::getId($module);

		$sqlresult = $adb->query("select actionid from vtiger_actionmapping where actionname = '$action'");
		if($adb->num_rows($sqlresult) < 1) return;

		$actionid = $adb->query_result($sqlresult, 0, 'actionid');

		$enable_disable = ($enable_disable == true)? '0' : '1';

		if($profile_id == null) {
			$sqlresult = $adb->query("select profileid from vtiger_profile");
			$profilecnt = $adb->num_rows($sqlresult);
			for($pridx = 0; $pridx < $profilecnt; ++$pridx) {
				$profileid = $adb->query_result($sqlresult, $pridx, "profileid");
				$adb->query("INSERT INTO vtiger_profile2utility (profileid, tabid, activityid, permission)
					VALUES($profileid, $tabid, $actionid, $enable_disable)");

				Vtiger_Utils::Log( (($enable_disable == '0')? 'Enabling':'Disabling') . 
					" Action $action for module $module for Profile $profileid ... DONE");
			}
		} else {
			$adb->query("INSERT INTO vtiger_profile2utility (profileid, tabid, activityid, permission)
				VALUES($profile_id, $tabid, $actionid, $enable_disable)");

			Vtiger_Utils::Log( (($enable_disable == '0')? 'Enabling':'Disabling') .
			   	" Action $action for module $module for Profile $profileid ... DONE");			
		}
	}



	static function syncToFile() {
		create_tab_data_file();
	}

	/**
	 * Generate the unique tab id.
	 */
	static function getUniqueId() {
		global $adb;
		$tabsql = "SELECT MAX(tabid) as max_tabid from vtiger_tab";
		$tabres = $adb->query($tabsql);
		$tabid  = $adb->query_result($tabres, 0, 'max_tabid');
		return ++$tabid;
	}

	static function getNextSequence() {
		global $adb;
		$tabsql = "SELECT MAX(tabsequence) as max_tabsequence from vtiger_tab";
		$tabres = $adb->query($tabsql);
		$tabseq = $adb->query_result($tabres, 0, 'max_tabsequence');
		return ++$tabseq;
	}

}

?>

