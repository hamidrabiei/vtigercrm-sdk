<?php

class Vtiger_Utils {
	static function Log($message) {
		global $Vtiger_Utils_Log;
		if(!isset($Vtiger_Utils_Log) || $Vtiger_Utils_Log == false) return;

		print_r($message);
		if(isset($_REQUEST)) echo "<BR>";
		else echo "\n";		
	}

	static function SQLEscape($value) {
		if($value == null) return $value;
		return mysql_real_escape_string($value);
	}

	static function CheckTable($tablename) {
		global $adb;
		$old_dieOnError = $adb->dieOnError;
		$adb->dieOnError = false;

		$tablecheck = $adb->query("select count(*) as count from $tablename");

		$tablePresent = true;
		if(!isset($tablecheck) || $tablecheck == null || $adb->num_rows($tablecheck) <= 0)
			$tablePresent = false;

		$adb->dieOnError = $old_dieOnError;
		return $tablePresent;
	}

	static function CreateTable($tablename, $criteria) {
		global $adb;

		$org_dieOnError = $adb->dieOnError;
		$adb->dieOnError = false;
		$adb->query("CREATE TABLE " . $tablename . $criteria);
		$adb->dieOnError = $org_dieOnError;	
	}

	static function AlterTable($tablename, $criteria) {
		global $adb;

		$adb->query("ALTER TABLE " . $tablename . $criteria);

	}
}

?>
