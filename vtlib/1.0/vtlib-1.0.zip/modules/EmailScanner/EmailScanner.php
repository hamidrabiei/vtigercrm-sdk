<?php

require_once('data/CRMEntity.php');
require_once('data/Tracker.php');

class EmailScanner extends CRMEntity {
	var $db, $log; // Used in class functions like CRMEntity

	var $table_name = 'vtiger_emailscanner';
	var $table_index= 'emailscannerid';
	var $column_fields = Array();

	// Mandatory for function getGroupName
	// Array(groupTableName, groupColumnId)
	// groupTableName should have (groupname column)
	var $groupTable = Array('vtiger_emailscannergrouprel', 'emailscannerid');

	// Mandatory for Saving
	var $tab_name = Array('vtiger_crmentity', 'vtiger_emailscanner');
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_emailscanner'   => 'emailscannerid');

	// Mandatory for Listing
	var $list_fields = Array (
		// Field Label=> Array(tablename, columnname)
		'EmailScanner Name'=> Array('payslip', 'emailscannername'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array(
		// Field Label=>columnname
		'EmailScanner Name'=> 'emailscannername',
		'Assigned To' => 'assigned_user_id'
	);
	var $sortby_fields = Array('emailscannername', 'smownerid', 'createdtime', 'modifiedtime');
	// Should contain field labels
	var $detailview_links = Array('EmailScannerName', 'Month');

	var $default_order_by = 'emailscannername';
	var $default_sort_order='ASC';

	function EmailScanner() {
		global $log, $currentModule;
		$this->column_fields = getColumnFields($currentModule);
		$this->db = new PearDatabase();
		$this->log = $log;
	}

	function getSortOrder() {
		global $currentModule;

		$sortorder = $this->default_sort_order;
		if($_REQUEST['sorder']) $sortorder = $_REQUEST['sorder'];
		else if($_SESSION[$currentModule.'_Sort_Order']) 
			$sortorder = $_SESSION[$currentModule.'_Sort_Order'];

		return $sortorder;
	}

	function getOrderBy() {
		$orderby = $this->default_order_by;
		if($_REQUEST['order_by']) $orderby = $_REQUEST['order_by'];
		else if($_SESSION[$currentModule.'_Order_By'])
			$orderby = $_SESSION[$currentModule.'_Order_By'];
		return $orderby;
	}

	function save_module($module) {
	}

	function getListQuery() {
		$query = "SELECT vtiger_crmentity.*, $this->table_name.* FROM $this->table_name
			INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = $this->table_name.$this->table_index
			LEFT JOIN vtiger_users ON vtiger_users.id = vtiger_crmentity.smownerid
			LEFT JOIN " . $this->groupTable[0] . " ON " . $this->groupTable[0].'.'.$this->groupTable[1] . " = $this->table_name.$this->table_index
			LEFT JOIN vtiger_groups ON vtiger_groups.groupname = " . $this->groupTable[0] . '.' . $this->groupTable[1];
		$query .= "	WHERE vtiger_crmentity.deleted = 0";
		// TODO: Take care of non_admin query security restriction
		return $query;
	}

}

?>
