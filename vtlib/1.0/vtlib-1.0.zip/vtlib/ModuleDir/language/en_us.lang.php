<?php

$mod_strings = Array(
	'ModuleName' => 'Module Name',

	'LBL_MODULEBLOCK_INFORMATION' => 'ModuleBlock Information',

	'ModuleFieldLabel' => 'ModuleFieldLabel Text',
);

?>
