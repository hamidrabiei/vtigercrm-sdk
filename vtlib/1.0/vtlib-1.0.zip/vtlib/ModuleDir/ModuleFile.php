<?php

require_once('data/CRMEntity.php');
require_once('data/Tracker.php');

class ModuleClass extends CRMEntity {
	var $db, $log; // Used in class functions like CRMEntity

	var $table_name = 'vtiger_payslip';
	var $table_index= 'payslipid';
	var $column_fields = Array();

	// Mandatory for function getGroupName
	// Array(groupTableName, groupColumnId)
	// groupTableName should have (groupname column)
	var $groupTable = Array('vtiger_payslipgrouprel', 'payslipid');

	// Mandatory for Saving
	var $tab_name = Array('vtiger_crmentity', 'vtiger_payslip');
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_payslip'   => 'payslipid');

	// Mandatory for Listing
	var $list_fields = Array (
		// Field Label=> Array(tablename, columnname)
		'Payslip Name'=> Array('payslip', 'payslipname'),
		'Assigned To' => Array('crmentity','smownerid')
	);
	var $list_fields_name = Array(
		// Field Label=>columnname
		'Payslip Name'=> 'payslipname',
		'Assigned To' => 'assigned_user_id'
	);
	var $sortby_fields = Array('payslipname', 'payslipmonth', 'smownerid', 'modifiedtime');
	// Should contain field labels
	var $detailview_links = Array('PayslipName', 'Month');

	var $default_order_by = 'payslipname';
	var $default_sort_order='ASC';

	function ModuleClass() {
		global $log, $currentModule;
		$this->column_fields = getColumnFields($currentModule);
		$this->db = new PearDatabase();
		$this->log = $log;
	}

	function getSortOrder() {
		global $currentModule;

		$sortorder = $this->default_sort_order;
		if($_REQUEST['sorder']) $sortorder = $_REQUEST['sorder'];
		else if($_SESSION[$currentModule.'_Sort_Order']) 
			$sortorder = $_SESSION[$currentModule.'_Sort_Order'];

		return $sortorder;
	}

	function getOrderBy() {
		$orderby = $this->default_order_by;
		if($_REQUEST['order_by']) $orderby = $_REQUEST['order_by'];
		else if($_SESSION[$currentModule.'_Order_By'])
			$orderby = $_SESSION[$currentModule.'_Order_By'];
		return $orderby;
	}

	function save_module($module) {
	}

	function getListQuery() {
		$query = "SELECT vtiger_crmentity.*, $this->table_name.* FROM $this->table_name
			INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = $this->table_name.$this->table_index
			LEFT JOIN vtiger_users ON vtiger_users.id = vtiger_crmentity.smownerid
			LEFT JOIN " . $this->groupTable[0] . " ON " . $this->groupTable[0].'.'.$this->groupTable[1] . " = $this->table_name.$this->table_index
			LEFT JOIN vtiger_groups ON vtiger_groups.groupname = " . $this->groupTable[0] . '.' . $this->groupTable[1];
		$query .= "	WHERE vtiger_crmentity.deleted = 0";
		// TODO: Take care of non_admin query security restriction
		return $query;
	}

}

?>
