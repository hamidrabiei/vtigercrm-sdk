<?php
require_once('vtlib/Vtiger/PackageImport.php');

/**
 * Package Manager class for vtiger Modules.
 */
class Vtiger_Package extends Vtiger_PackageImport {

	function Vtiger_Package() {
		parent::__construct();
	}
}
?>
