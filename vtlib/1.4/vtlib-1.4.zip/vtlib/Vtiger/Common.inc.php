<?php

include_once('include/utils/utils.php');
include_once('include/database/PearDatabase.php');

include_once('vtlib/Vtiger/Utils.php');

?>
