<?php

include_once('vtlib/Vtiger/Block.php');

Vtiger_Block::create('Payslip', 'LBL_PAYSLIP_INFORMATION');

?>
