<?php
require_once('include/Ajax/CommonAjax.php');
?>
