var app_strings = {
	'LBL_APP'       : 'vtiger CRM',
	'LBL_APP_TITLE' : 'vtiger Offline Client',
	'LBL_OFFLINE' : 'Offline',
	'LBL_ONLINE'  : 'Online',
	'LBL_RECORDS' : 'Records',
	'LBL_WELCOME' : 'Welcome',
	'LBL_LOGOUT'  : 'Logout',
	'LBL_USERNAME': 'Username',
	'LBL_ACCESSKEY':'Access Key',
	'LBL_SERVICEURL':'vtiger URL',
	'LBL_LOGIN'   : 'Login',
	'LBL_CREATE'  : 'Create',
	'LBL_SAVE'    : 'Save',
	'LBL_CANCEL'  : 'Cancel',
	'LBL_COLUMNS' : 'Columns'
}
