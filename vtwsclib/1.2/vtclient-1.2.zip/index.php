<?php
include_once('vtwsclib/Vtiger/WSClient.php');

@session_start();

include_once('vtclient.php');
include_once('ExtSmarty.php');

$smarty = new ExtSmarty();

if(!vtclient::CheckLogin()) { 
	$smarty->assign('THEMES', IndexPage::GetThemes());
	$smarty->assign('THEME', vtclient::GetFromSession('theme'));
	$smarty->display('Login.tpl'); 
} 
else {

	$smarty_file = 'Home.tpl';
	$redirect_to = '';

	// Common processing		
	$client = vtclient::GetServiceClient();
	$view = $_REQUEST['view'];
	$module = $_REQUEST['module'];

	$modules = vtclient::GetFromSession('modules');
	if(!$modules) {
		$allmodules = $client->doListTypes();
		$modules = Array();
		foreach($allmodules as $modulename=>$moduleinfo) {
			if(!isset($moduleinfo['isEntity'])|| $moduleinfo['isEntity'] == 1) {
				$modules[] = $modulename;
			}
		}
		sort($modules);
		vtclient::PutInSession(null, 'modules', $modules);
	}
	$theme = vtclient::GetFromSession('theme');

	$smarty->assign('MODULE', $module);
	$smarty->assign('USERNAME', $client->_serviceuser);
	$smarty->assign('MODULES', $modules);
	$smarty->assign('THEME', vtclient::GetFromSession('theme'));
	
	// Request specific processing
	switch($view) {
	case 'describe':
		IndexPage::ProcessDescribeRequest($client, $smarty, $module);
		$smarty_file = 'ListView.tpl';
		break;
	case 'list':
		IndexPage::ProcessListRequest($client, $smarty, $module);
		$smarty_file = 'ListView.tpl';
		break;
	case 'list.columns':
		IndexPage::ProcessListColumnsRequest($client, $smarty, $module);
		$smarty_file = 'ListColumns.tpl';
		break;
	case 'list.columns.save':
		IndexPage::ProcessListColumnsSaveRequest($client, $smarty, $module);
		$smarty_file = '';
		$redirect_to = "index.php?module=$module&view=list";
		break;
	case 'search.form':
		//IndexPage::ProcessSearchFormRequest($client, $smarty, $module);
		$smarty_file = 'SearchForm.tpl';
		break;
	case 'search':
		IndexPage::ProcessSearchRequest($client, $smarty, $module);
		$smarty_file = 'SearchView.tpl';
		break;
	case 'detail':
		IndexPage::ProcessDetailRequest($client, $smarty, $module, $_REQUEST['record']);
		$smarty_file = 'DetailView.tpl';
		break;
	case 'prefs':
		IndexPage::ProcessMyPrefsRequest($smarty);
		$smarty_file = 'MyPrefs.tpl';
		break;
	case 'prefssave':
		IndexPage::ProcessMyPrefsSaveRequest();
		$redirect_to = 'index.php?view=prefs';
		$smarty_file = '';
		break;
	}

	if($redirect_to) { 
		header("Location: $redirect_to");
		exit;
	} else if($smarty_file) {
		$smarty->display($smarty_file);
	}
}

class IndexPage {
	static function GetDescribeInfo($client, $module) {
		// Get describe information from cache or Cache it		
		$mysession = vtclient::GetMySession();
		$describeInfo = $mysession->describe[$module];
		if(!$describeInfo) {
			$describeInfo = $client->doDescribe($module);
			$mysession->describe[$module] = Array();
			$mysession->describe[$module]['CREATE'] = $describeInfo[createable];
			$mysession->describe[$module]['UPDATE'] = $describeInfo[updateable];
			$mysession->describe[$module]['DELETE'] = $describeInfo[deleteable];
			$mysession->describe[$module]['READ']   = $describeInfo[retrieveable];
			$mysession->describe[$module]['FIELDS'] = Array();

			foreach($describeInfo[fields] as $field) {
				$mysession->describe[$module]['FIELDS'][$field[name]] = $field;
			}
			vtclient::PutInSession($mysession);
		}
		return $mysession->describe[$module];
	}

	static function ProcessDescribeRequest($client, $smarty, $module) {
		$describeInfo = self::GetDescribeInfo($client, $module);
		$smarty->assign('DESCRIBE', $describeInfo);
	}

	static function ProcessListRequest($client, $smarty, $module) {
		$mysession = vtclient::GetMySession();
		$columns = $mysession->listcols[$module];
		$limit   = $mysession->fetchlimit;

		$start_limit = $_REQUEST['start'];
		if(!isset($start_limit)) $start_limit = 0;

		$end_limit   = $start_limit + $limit;

		if(empty($columns)) $columns = Array('*');

		$columnString = implode(',', $columns);
		$records = $client->doQuery("SELECT $columnString from $module limit $start_limit, $end_limit");
		$columns = $client->getResultColumns($records);

		$has_more_records = true;
		if(count($records) < ($end_limit - $start_limit)) {
			$has_more_records = false;
		}

		$describeInfo = self::GetDescribeInfo($client, $module);
		/*$columnsmeta  = Array();
		foreach($columns as $column) {
			$columnsmeta[$column] = Array ( 'label' => $describeInfo['FIELDS'][$column]['label'] );
		}*/
		$columnsmeta = $describeInfo['FIELDS'];

		$smarty->assign('COLUMNS', $columns);		
		$smarty->assign('COLUMNSMETA', $columnsmeta);
		$smarty->assign('RECORDS', $records);
		$smarty->assign('PREV_START_LIMIT', ($start_limit - $limit));
		$smarty->assign('NEXT_START_LIMIT', $end_limit);
		$smarty->assign('HAS_MORE', $has_more_records);
	}
	
	static function ProcessSearchRequest($client, $smarty, $module) {
		$mysession = vtclient::GetMySession();
		$columns = $mysession->listcols[$module];
		// TODO: Make it SQL Injection SAFE, without using mysql_real_escape_string
		$searchfor = vtclient::SQLEscape($_REQUEST['searchfor']);
		$limit   = $mysession->fetchlimit;

		$start_limit = $_REQUEST['start'];
		if(!isset($start_limit)) $start_limit = 0;

		$end_limit   = $start_limit + $limit;

		$columnString = implode(',', $columns);
		$likeString = '';
		for($index = 0; $index < count($columns); ++$index) {
			$column = $columns[$index];
			$likeString .= "$column LIKE '$searchfor'";
			if($index != (count($columns)-1)) $likeString .= ' OR ';
		}

		$records = $client->doQuery("SELECT $columnString from $module WHERE $likeString limit $start_limit, $end_limit");
		$columns = $client->getResultColumns($records);

		$has_more_records = true;
		if(count($records) < ($end_limit - $start_limit)) {
			$has_more_records = false;
		}

		$describeInfo = self::GetDescribeInfo($client, $module);
		/*$columnsmeta  = Array();
		foreach($columns as $column) {
			$columnsmeta[$column] = Array ( 'label' => $describeInfo['FIELDS'][$column]['label'] );
		}*/
		$columnsmeta = $describeInfo['FIELDS'];

		$smarty->assign('COLUMNS', $columns);
		$smarty->assign('COLUMNSMETA', $columnsmeta);
		$smarty->assign('SEARCHFOR', $searchfor);
		$smarty->assign('RECORDS', $records);
		$smarty->assign('PREV_START_LIMIT', ($start_limit - $limit));
		$smarty->assign('NEXT_START_LIMIT', $end_limit);
		$smarty->assign('HAS_MORE', $has_more_records);
	}

	static function GetThemes() {
		$themedir = 'themes';
		$dirfiles = scandir($themedir);
		$cssfiles = Array();
		foreach($dirfiles as $filename) {
			if(is_file("$themedir/$filename")) $cssfiles[] = $filename;
		}
		return $cssfiles;
	}

	static function ProcessMyPrefsRequest($smarty) {
		$mysession = vtclient::GetMySession();
		$MYPREFS   = Array();
		$MYPREFS['FETCH_LIMIT'] = $mysession->fetchlimit;
		$MYPREFS['THEMES']      = self::GetThemes();
		$MYPREFS['THEME']       = $mysession->theme;
		$smarty->assign('MYPREFS', $MYPREFS);
	}
	static function ProcessMyPrefsSaveRequest() {
		$mysession = vtclient::GetMySession();
		$ismodified = false;

		$fetchlimit = $_REQUEST['FETCH_LIMIT'];
		if(is_numeric($fetchlimit)) {
			$mysession->fetchlimit = $fetchlimit;
			$ismodified = true;
		}

		$theme = htmlspecialchars(trim($_REQUEST['THEME']), ENT_QUOTES);		
		if($mysession->theme != $theme) {
			$mysession->theme = $theme;
			$ismodified = true;
		}
		if($ismodified) vtclient::PutInSession($mysession);
	}
	static function ProcessListColumnsRequest($client, $smarty, $module) {
		$mysession = vtclient::GetMySession();
		$describeInfo = self::GetDescribeInfo($client, $module);
		$smarty->assign('MODCOLS', $describeInfo['FIELDS']);
		$smarty->assign('LISTCOLS', $mysession->listcols[$module]);		
	}
	static function ProcessListColumnsSaveRequest($client, $smarty, $module) {
		$mysession = vtclient::GetMySession();
		$columns = Array();
		foreach($_REQUEST as $key=>$value) {
			$columnkeypos = strpos($key, 'column-');
			if($columnkeypos !== false && $columnkeypos == 0 && $value) {
				$columns[] = $value;
			}
		}
		if(!empty($columns)) { 
			$mysession->listcols[$module] = $columns;
			vtclient::PutInSession($mysession);
		}
	}
	static function ProcessDetailRequest($client, $smarty, $module, $record) {
		$mysession = vtclient::GetMySession();
		$describeInfo = self::GetDescribeInfo($client, $module);
		$recordInfo = $client->doRetrieve($record);
		
		$smarty->assign('MODCOLS', $describeInfo['FIELDS']);
		$smarty->assign("RECORDINFO", $recordInfo);
	}
}
?>
