<?php
require('Smarty/libs/Smarty.class.php');
include_once('language/en_us.lang.php');

class ExtSmarty extends Smarty {
	function __construct() {
		parent::__construct();

		$this->template_dir = 'Smarty/templates';
		$this->compile_dir  = 'Smarty/templates_c';
		$this->config_dir   = 'Smarty/configs';
		$this->cache_dir    = 'Smarty/cache';

		global $app_strings;
		$this->assign('APP', $app_strings);
	}
	function _getRecordId($id) {
		$ex = explode('x', $id);
		return $ex[1];
	}
}
?>
