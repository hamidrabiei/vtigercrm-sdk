<?php
require_once('MySession.php');

class vtclient {
	static function CheckLogin() {
		if(isset($_SESSION['VTCLIENT_WSCLIENT'])) {
				return true;
			}
		return false;
	}
	static function DoLogin($url, $username, $accesskey) {
		$client = new Vtiger_WSClient($url);
		$login  = $client->doLogin($username, $accesskey);
		if($login) {
			$_SESSION['VTCLIENT_WSCLIENT'] = serialize($client);
			return true;
		}
		return false;
	}
	static function DoLogout() {
		unset($_SESSION['VTCLIENT_WSCLIENT']);
		unset($_SESSION['VTCLIENT_MYSESSION']);
	}
	static function GetServiceClient() {
		$client = unserialize($_SESSION['VTCLIENT_WSCLIENT']);
		$client->reinitalize();
		return $client;
	}
	static function GetMySession() {
		$mysession = $_SESSION['VTCLIENT_MYSESSION'];
		if($mysession) $mysession = unserialize($mysession);
		else $mysession = new MySession();
		return $mysession;
	}
	static function PutInSession($mysession=null, $key=null, $value=null) {
		if(!$mysession) $mysession = self::GetMySession();
		if($key) $mysession->$key = $value;
		$_SESSION['VTCLIENT_MYSESSION'] = serialize($mysession);
	}
	static function GetFromSession($key) {
		$mysession =  self::GetMySession();
		return $mysession->$key;
	}
	static function SQLEscape($sql) {
		return addslashes($sql);
	}
}

?>
