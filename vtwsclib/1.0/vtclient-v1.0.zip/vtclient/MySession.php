<?php

class MySession {
	var $modules = false;
	var $describe = Array();
	var $listcols = Array();
	var $serachcols = Array();
	var $fetchlimit = 20;

	// Default Theme
	var $theme = 'theme.Gray';
	
	function __construct() {
		$this->listcols['Accounts']      = Array ('accountname');
		$this->listcols['Calendar']      = Array ('subject', 'date_start', 'time_start');
		$this->listcols['Campaigns']     = Array ('campaignname');
		$this->listcols['Contacts']      = Array ('firstname', 'lastname', 'account_id');
		$this->listcols['Documents']     = Array ('notes_title');
		$this->listcols['Emails']        = Array ('subject');
		$this->listcols['Faq']           = Array ('question');
		$this->listcols['HelpDesk']      = Array ('ticket_title', 'ticketstatus');
		$this->listcols['Invoice']       = Array ('subject', 'invoice_no');
		$this->listcols['Leads']         = Array ('firstname', 'lastname', 'company', 'email');
		$this->listcols['Potentials']    = Array ('potentialname', 'amount', 'closingdate');
		$this->listcols['PriceBooks']    = Array ('bookname', 'description');
		$this->listcols['Products']      = Array ('productname', 'unit_price', 'qtyinstock');
		$this->listcols['PurchaseOrder'] = Array ('subject');
		$this->listcols['Quotes']        = Array ('subject', 'quote_no', 'validtill');
		$this->listcols['SalesOrder']    = Array ('subject');
		$this->listcols['Users']         = Array ('user_name','email1','status');
		$this->listcols['Vendors']       = Array ('vendorname');
	}

}
?>
