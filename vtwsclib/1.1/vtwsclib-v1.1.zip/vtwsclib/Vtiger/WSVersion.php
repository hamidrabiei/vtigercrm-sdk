<?php
$wsclient_version = '1.0';
?>
