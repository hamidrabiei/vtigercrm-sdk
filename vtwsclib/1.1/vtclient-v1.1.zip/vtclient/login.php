<?php
include_once('vtwsclib/Vtiger/WSClient.php');

@session_start();
include_once('vtclient.php');

vtclient::DoLogin($_REQUEST['serviceURL'], 
	$_REQUEST['username'],
	$_REQUEST['accesskey']);

$theme = $_REQUEST['THEME'];
$theme = htmlspecialchars($theme, ENT_QUOTES);
vtclient::PutInSession(null, 'theme', $theme);

header('Location: index.php');

?>
