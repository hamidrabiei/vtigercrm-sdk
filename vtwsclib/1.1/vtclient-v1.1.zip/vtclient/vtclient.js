var vtclient = function() {}
vtclient.redirect = function($url) {
	vtclient.showProgressBar();
	location.href = $url;
}
vtclient.showProgressBar = function(message) {
	if(message == null) message = 'Loading...';

	var welcome = document.getElementById('welcome-span');
	if(welcome) welcome.style.display = 'none';

	var pbar = document.getElementById('progress-bar');
	if(pbar) pbar.style.display = 'inline';
	pbar.innerHTML = message;
}
vtclient.hideProgressBar = function() {
	var pbar = document.getElementById('progress-bar');
	if(pbar) pbar.style.display = 'none';

	var welcome = document.getElementById('welcome-span');
	if(welcome) welcome.style.display = 'inline';
}
