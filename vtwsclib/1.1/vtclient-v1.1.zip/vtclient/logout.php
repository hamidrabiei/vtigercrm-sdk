<?php
include_once('vtwsclib/Vtiger/WSClient.php');

@session_start();
include_once('vtclient.php');

vtclient::DoLogout();

header('Location: index.php');

?>
